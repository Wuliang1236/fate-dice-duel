import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { randomInt } from 'node:crypto';
import { room, player, act, view, presence } from './game.mjs';

export function createApp({ now = Date.now, rng = randomInt } = {}) {
  const rooms = new Map(), limits = new Map();
  const files = new Map([['/', ['index.html', 'text/html']], ['/app.js', ['app.js', 'text/javascript']],
    ['/style.css', ['style.css', 'text/css']], ['/effects.js', ['effects.js', 'text/javascript']],
    ['/audio.js', ['audio.js', 'text/javascript']]]);
  const reply = (res, status, data) => {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data));
  };
  const server = http.createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'");
    try {
      const time = now();
      for (const [code, r] of rooms) if (time - r.touchedAt > 30 * 60_000) rooms.delete(code);
      const url = new URL(req.url, 'http://localhost');
      if (!url.pathname.startsWith('/api/')) {
        if (req.method !== 'GET' || !files.has(url.pathname)) return reply(res, 404, { error: '页面不存在' });
        const [name, mime] = files.get(url.pathname);
        const body = await readFile(new URL(`./public/${name}`, import.meta.url));
        res.writeHead(200, { 'Content-Type': `${mime}; charset=utf-8` }); res.end(body); return;
      }
      const ip = req.socket.remoteAddress;
      for (const [key, v] of limits) if (time - v.start > 60_000) limits.delete(key);
      const rate = limits.get(ip) || { start: time, count: 0 };
      limits.set(ip, rate);
      if (++rate.count > 600) return reply(res, 429, { error: '请求过于频繁，请稍后再试' });
      let body = {};
      if (req.method === 'POST') {
        // 浏览器只能从当前站点提交操作，邀请码不是身份凭证。
        if (req.headers.origin && new URL(req.headers.origin).host !== req.headers.host)
          return reply(res, 403, { error: '不允许跨站操作' });
        let raw = '';
        for await (const chunk of req) {
          raw += chunk;
          if (Buffer.byteLength(raw) > 4096) return reply(res, 413, { error: '请求过大' });
        }
        try { body = JSON.parse(raw || '{}'); } catch { return reply(res, 400, { error: '请求格式错误' }); }
        if (!body || Array.isArray(body) || typeof body !== 'object') return reply(res, 400, { error: '请求格式错误' });
      }
      if (url.pathname === '/api/create' && req.method === 'POST') {
        if (rooms.size >= 200) return reply(res, 503, { error: '房间已满，请稍后再试' });
        let code;
        do { code = randomInt(0x100000, 0xFFFFFF).toString(16).toUpperCase(); } while (rooms.has(code));
        const r = room(code, body.name, time); rooms.set(code, r);
        return reply(res, 201, { code, token: r.players[0].token });
      }
      const code = String(body.code || url.searchParams.get('code') || '').toUpperCase();
      const r = rooms.get(code);
      if (!r) return reply(res, 404, { error: '房间不存在或已过期，请重新创建' });
      if (url.pathname === '/api/join' && req.method === 'POST') {
        if (r.players.length >= 2) return reply(res, 409, { error: '房间已有两位玩家' });
        r.players.push(player(body.name, time)); r.touchedAt = time;
        return reply(res, 200, { code, token: r.players[1].token });
      }
      const auth = req.headers.authorization?.replace(/^Bearer /, '');
      const who = r.players.findIndex(p => p.token === auth);
      if (who < 0) return reply(res, 401, { error: '身份已失效，请重新加入房间' });
      presence(r, time); // 先核对是否已超时，再刷新心跳，不能通过刷新复活已结束的对局。
      r.players[who].lastSeen = time; r.touchedAt = time;
      if (url.pathname === '/api/state' && req.method === 'GET') return reply(res, 200, view(r, who, time));
      if (url.pathname === '/api/action' && req.method === 'POST') {
        try { act(r, who, body.action, body, time, rng); }
        catch (e) { return reply(res, 409, { error: e.message }); }
        return reply(res, 200, view(r, who, time));
      }
      reply(res, 404, { error: '接口不存在' });
    } catch { if (!res.headersSent) reply(res, 500, { error: '服务暂时不可用，请重试' }); else res.end(); }
  });
  return { server, rooms };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 3000);
  createApp().server.listen(port, '0.0.0.0', () => console.log(`命运之戏正在监听端口 ${port}`));
}
