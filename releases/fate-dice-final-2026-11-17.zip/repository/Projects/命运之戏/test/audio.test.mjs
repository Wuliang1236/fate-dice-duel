import test from 'node:test';
import assert from 'node:assert/strict';
import { createAudioController } from '../public/audio.js';

function audioHarness() {
  const events = {}, sources = [];
  const parameter = () => ({ value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {} });
  class FakeAudio {
    constructor() { this.state = 'running'; this.currentTime = 0; this.sampleRate = 100; this.destination = {}; }
    createGain() { return { gain: parameter(), connect() {} }; }
    createBiquadFilter() { return { frequency: parameter(), connect() {} }; }
    createBuffer() { return { getChannelData: () => new Float32Array(160) }; }
    makeSource() {
      const source = { frequency: parameter(), stops: [], connect() {}, start() {}, stop(time) { this.stops.push(time); } };
      sources.push(source); return source;
    }
    createOscillator() { return this.makeSource(); }
    createBufferSource() { return this.makeSource(); }
  }
  const browser = { AudioContext: FakeAudio, addEventListener(name, fn) { events[name] = fn; } };
  return { controller: createAudioController(browser), events, sources };
}

test('音效需玩家交互激活，静音会停止正在播放的声音', () => {
  const { controller, events, sources } = audioHarness();
  controller.play('energy'); assert.equal(sources.length, 0);
  events.pointerdown(); controller.play('energy'); assert.equal(sources.length, 3);
  controller.setEnabled(false);
  assert.ok(sources.every(source => source.stops.includes(undefined)));
  controller.play('hand'); assert.equal(sources.length, 3);
  controller.setEnabled(true); controller.activate(); controller.play('hand'); assert.equal(sources.length, 5);
});

test('更高级别的索尔怒袭有更长的雷声', () => {
  const { controller, events, sources } = audioHarness();
  events.keydown(); controller.play('thunder', 1);
  const levelOne = Math.max(...sources.flatMap(source => source.stops));
  const start = sources.length; controller.play('thunder', 3);
  const levelThree = Math.max(...sources.slice(start).flatMap(source => source.stops));
  assert.ok(levelThree > levelOne);
});
