import test from 'node:test';
import assert from 'node:assert/strict';
import { room, player, act, view, settle, presence, GOLD_FACES } from '../game.mjs';
import { createApp } from '../server.mjs';

function fixture() {
  const r = room('ABC123', '甲', 1000); r.players.push(player('乙', 1000)); return r;
}
function start(r) {
  act(r, 0, 'ready', {}, 1000, () => 0); act(r, 1, 'ready', {}, 1000, () => 0);
}
const dice = (symbol, gold = false) => Array.from({ length: 6 }, () => ({ symbol, gold }));
function battle() {
  const r = fixture(); start(r); r.phase = 'favor';
  r.players.forEach(p => { p.dice = dice('helmet'); p.favor = 0; }); return r;
}
test('双方准备后开局，固定带框面配置有效', () => {
  const r = fixture(); act(r, 0, 'ready', {}, 1000); assert.equal(r.phase, 'lobby');
  act(r, 1, 'ready', {}, 1000, () => 0); assert.equal(r.phase, 'rolling'); assert.equal(r.first, 0);
  assert.ok(GOLD_FACES.every(f => f.length === 2 && new Set(f).size === 2 && f.every(n => n >= 0 && n < 6)));
});
test('轮流投骰、禁止重复投掷，保留骰子不重掷，第三轮全部锁定', () => {
  const r = fixture(); start(r);
  assert.throws(() => act(r, 1, 'roll', {}, 1000), /不能投骰/);
  act(r, 0, 'roll', {}, 1000, () => 5);
  assert.throws(() => act(r, 0, 'roll', {}, 1000), /不能投骰/);
  act(r, 0, 'keep', { held: [true, false, false, false, false, false] }, 1000);
  act(r, 1, 'roll', {}, 1000, () => 0); act(r, 1, 'keep', { held: Array(6).fill(false) }, 1000);
  act(r, 0, 'roll', {}, 1000, () => 2);
  assert.equal(r.players[0].dice[0].symbol, 'hand'); assert.equal(r.players[0].dice[1].symbol, 'arrow');
  act(r, 0, 'keep', { held: Array(6).fill(false) }, 1000);
  while (r.phase === 'rolling') {
    act(r, r.turn, 'roll', {}, 1000, () => 0);
    act(r, r.turn, 'keep', { held: Array(6).fill(false) }, 1000);
  }
  assert.equal(r.phase, 'favor'); assert.ok(r.players.every(p => p.rolls === 3 && p.held.every(Boolean)));
});
test('非法保留参数和恩惠等级被拒绝', () => {
  const r = fixture(); start(r); act(r, 0, 'roll', {}, 1000, () => 0);
  assert.throws(() => act(r, 0, 'keep', { held: [true] }, 1000), /参数/);
  r.phase = 'favor'; assert.throws(() => act(r, 0, 'favor', { level: 99 }, 1000), /等级/);
});
test('能量先发放再偷取，不会出现负数', () => {
  const r = battle(); r.players[0].dice = dice('hand', true);
  r.players[1].dice = dice('helmet', true); settle(r);
  assert.equal(r.players[0].energy, 12); assert.equal(r.players[1].energy, 0);
});
test('双向偷取按先手顺序执行', () => {
  const r = battle(); r.players.forEach(p => { p.dice = dice('hand'); p.energy = 2; });
  settle(r); assert.deepEqual(r.players.map(p => p.energy), [0, 4]);
});
test('防御只抵消对应类型', () => {
  const r = battle(); r.players[0].dice = dice('arrow'); settle(r);
  assert.equal(r.players[1].hp, 9);
  const s = battle(); s.players[0].dice = dice('axe'); settle(s);
  assert.equal(s.players[1].hp, 15);
});
test('同时致命判平局，普通攻击死亡不再释放恩惠', () => {
  const r = battle(); r.players.forEach(p => { p.hp = 6; p.energy = 12; p.dice = dice('axe'); p.favor = 3; });
  settle(r); assert.equal(r.winner, -1); assert.equal(r.phase, 'finished');
  assert.equal(r.players[0].energy, 12);
});
test('偷取导致已选择恩惠失效，不扣除剩余能量', () => {
  const r = battle(); r.players[0].energy = 8; r.players[0].favor = 2;
  r.players[1].dice = dice('hand'); settle(r);
  assert.equal(r.players[0].energy, 2); assert.equal(r.players[1].hp, 15);
  assert.ok(r.log.some(x => x.includes('未发动')));
});
test('可用当回合新增能量发动恩惠，先手致命后结束', () => {
  const r = battle(); r.players[0].dice = dice('helmet', true); r.players[0].favor = 1;
  r.players[1].hp = 2; r.players[1].energy = 12; r.players[1].favor = 3;
  settle(r); assert.equal(r.winner, 0); assert.equal(r.players[0].energy, 2); assert.equal(r.players[0].hp, 15);
});
test('结算动画记录与真实能量、格挡、伤害及恩惠顺序一致', () => {
  const r = battle();
  r.players[0].energy = 4; r.players[1].energy = 2;
  r.players[0].dice = [
    { symbol: 'axe', gold: true }, { symbol: 'axe', gold: false }, { symbol: 'arrow', gold: false },
    { symbol: 'hand', gold: false }, { symbol: 'helmet', gold: false }, { symbol: 'shield', gold: false }
  ];
  r.players[1].dice = [
    { symbol: 'helmet', gold: false }, { symbol: 'shield', gold: false }, { symbol: 'hand', gold: true },
    { symbol: 'arrow', gold: false }, { symbol: 'axe', gold: false }, { symbol: 'hand', gold: true }
  ];
  r.players.forEach(p => { p.favor = 1; });
  assert.equal(view(r, 0, 1000).settlement, null);
  settle(r);
  const replay = view(r, 0, 1000).settlement;
  assert.deepEqual(replay.before, [{ hp: 15, energy: 4 }, { hp: 15, energy: 2 }]);
  assert.deepEqual(replay.events.map(e => e.type), ['energy', 'energy', 'steal', 'steal', 'combat', 'favor', 'favor']);
  assert.deepEqual(replay.events.filter(e => e.type === 'steal').map(e => e.amount), [1, 2]);
  const combat = replay.events.find(e => e.type === 'combat');
  assert.deepEqual(combat.attacks.filter(a => a.player === 0), [
    { player: 0, die: 0, symbol: 'axe', blockedBy: 0 },
    { player: 0, die: 1, symbol: 'axe', blockedBy: null },
    { player: 0, die: 2, symbol: 'arrow', blockedBy: 1 }
  ]);
  assert.deepEqual(combat.damage, [1, 0]);
  assert.deepEqual(replay.events.at(-1).after, r.players.map(({ hp, energy }) => ({ hp, energy })));
  assert.deepEqual(view(r, 1, 1000).settlement, replay);
  act(r, 0, 'ready', {}, 1000); act(r, 1, 'ready', {}, 1000);
  assert.equal(view(r, 0, 1000).settlement, null);
});
test('致命普通攻击后不会记录恩惠动画；能量不足只记录失效', () => {
  const r = battle(); r.players.forEach(p => { p.hp = 6; p.energy = 12; p.dice = dice('axe'); p.favor = 3; });
  settle(r); assert.equal(r.settlement.events.at(-1).type, 'combat');
  assert.ok(!r.settlement.events.some(e => e.type === 'favor'));
  const s = battle(); s.players[0].energy = 8; s.players[0].favor = 2; s.players[1].dice = dice('hand');
  settle(s); assert.ok(s.settlement.events.some(e => e.type === 'fizzle' && e.player === 0));
  assert.ok(!s.settlement.events.some(e => e.type === 'favor' && e.player === 0));
});
test('对手看不到恩惠等级和身份令牌', () => {
  const r = battle(); r.players[0].favor = 3;
  const v = view(r, 1, 1000);
  assert.equal(v.players[0].favor, null); assert.equal(v.players[0].favorChosen, true);
  assert.ok(!JSON.stringify(v).includes(r.players[0].token));
});
test('双方确认后切换先手，并重置骰子保留生命与能量', () => {
  const r = battle(); settle(r); r.players[0].hp = 10; r.players[0].energy = 3;
  act(r, 0, 'ready', {}, 1000); act(r, 1, 'ready', {}, 1000);
  assert.equal(r.round, 2); assert.equal(r.first, 1); assert.equal(r.players[0].hp, 10);
  assert.equal(r.players[0].energy, 3); assert.ok(r.players[0].dice.every(d => d === null));
});
test('离线暂停、60 秒判负，超时前恢复可继续', () => {
  const r = fixture(); start(r); r.players[0].lastSeen = 8000;
  assert.equal(view(r, 0, 8000).paused, true);
  assert.throws(() => act(r, 0, 'roll', {}, 8000), /暂停/);
  r.players[1].lastSeen = 8000; act(r, 0, 'roll', {}, 8000, () => 0);
  r.players[0].lastSeen = 68000; presence(r, 68000); assert.equal(r.winner, 0);
  const s = fixture(); start(s); presence(s, 61000); assert.equal(s.winner, -1);
});
test('HTTP：两名独立客户端完成整局；拒绝第三人、越权和跨站操作', async t => {
  const { server } = createApp({ rng: () => 0 });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  const base = `http://127.0.0.1:${server.address().port}`;
  async function call(path, data, credential) {
    const res = await fetch(base + path, { method: data ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json', ...(credential ? { Authorization: `Bearer ${credential}` } : {}) },
      body: data ? JSON.stringify(data) : undefined });
    return { status: res.status, data: await res.json() };
  }
  const a = (await call('/api/create', { name: '甲' })).data;
  const b = (await call('/api/join', { code: a.code, name: '乙' })).data;
  assert.equal((await call('/api/join', { code: a.code })).status, 409);
  assert.equal((await call(`/api/state?code=${a.code}`)).status, 401);
  const cross = await fetch(base + '/api/action', { method: 'POST', headers: { Origin: 'https://other.example', 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(cross.status, 403);
  const tokens = [a.token, b.token];
  async function action(i, action, extras = {}) {
    const response = await call('/api/action', { code: a.code, action, ...extras }, tokens[i]);
    assert.equal(response.status, 200, response.data.error); return response.data;
  }
  await action(0, 'ready'); let s = await action(1, 'ready');
  for (let n = 0; n < 100 && s.phase !== 'finished'; n++) {
    if (s.phase === 'rolling') {
      await action(s.turn, 'roll'); s = await action(s.turn, 'keep', { held: Array(6).fill(false) });
    } else if (s.phase === 'favor') { await action(0, 'favor', { level: 0 }); s = await action(1, 'favor', { level: 0 }); }
    else { await action(0, 'ready'); s = await action(1, 'ready'); }
  }
  assert.equal(s.phase, 'finished'); assert.equal(s.winner, -1);
  const other = (await call(`/api/state?code=${a.code}`, null, a.token)).data;
  assert.deepEqual(other.players, s.players); assert.deepEqual(other.log, s.log);
  const page = await fetch(base); assert.equal(page.status, 200);
  assert.match(await page.text(), /命运之戏/);
});
test('HTTP：刷新保留身份，超时不能复活；无活动房间回收', async t => {
  let now = 1000; const { server, rooms } = createApp({ now: () => now, rng: () => 0 });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  const r = fixture(); start(r); rooms.set(r.code, r);
  const url = `http://127.0.0.1:${server.address().port}/api/state?code=${r.code}`;
  const headers = { Authorization: `Bearer ${r.players[0].token}` };
  let v = await (await fetch(url, { headers })).json(); assert.equal(v.you, 0);
  now = 61000; r.players[1].lastSeen = now;
  v = await (await fetch(url, { headers })).json(); assert.equal(v.phase, 'finished'); assert.equal(v.winner, 1);
  now += 31 * 60_000; assert.equal((await fetch(url, { headers })).status, 404);
});
