const base='https://fate-dice-duel.sassyoasis16.chatgpt.site';
for (const path of ['/', '/app.js','/style.css']) {
 const response=await fetch(base+path,{signal:AbortSignal.timeout(15000)});
 const body=await response.text();
 if(!response.ok) throw Error(`${path}: ${response.status}`);
 if(path==='/' && !body.includes('命运之戏')) throw Error('Missing game markup');
 if(path==='/app.js' && !body.includes('/api/create') && !body.includes('/api/${kind}')) throw Error('Missing client logic');
 console.log(JSON.stringify({path,status:response.status,type:response.headers.get('content-type'),bytes:Buffer.byteLength(body)}));
}
