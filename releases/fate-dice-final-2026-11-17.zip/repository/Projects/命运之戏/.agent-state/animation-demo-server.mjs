// 本机视觉验收夹具：预置符文、手套、攻防与高等级恩惠，不用于正式服务。
import { createApp } from '../server.mjs';
import { room } from '../game.mjs';

const { server, rooms } = createApp();
const r = room('D1CE01', '雷神的试炼');
rooms.set(r.code, r);
let prepared = false;
setInterval(() => {
  r.players[0].lastSeen = Date.now();
  if (!prepared && r.players.length === 2) {
    prepared = true; r.phase = 'favor'; r.round = 1; r.first = 0;
    const set = (symbol, gold = false) => ({ symbol, gold });
    r.players[0].dice = [set('axe', true), set('arrow', true), set('hand', true), set('helmet'), set('shield'), set('hand')];
    r.players[1].dice = [set('axe', true), set('arrow', true), set('hand', true), set('helmet'), set('shield'), set('axe')];
    r.players.forEach(p => { p.hp = 15; p.energy = 16; p.rolls = 3; p.held.fill(true); });
    r.players[0].favor = 3; r.players[1].favor = null;
    r.log.push('第 1 回合 · 雷神的试炼 先手');
  }
}, 100);
const port = Number(process.env.FATE_DEMO_PORT || 3175);
server.listen(port, '127.0.0.1', () => console.log(`动画验收夹具：http://127.0.0.1:${port}/?room=D1CE01`));
