import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
const base = process.argv[2];
if (!base?.startsWith('https://')) throw Error('Expected hosted HTTPS URL');
let sessions=[], polling=false;
async function call(path, data, credential) {
  const r=await fetch(base+path,{method:data?'POST':'GET',headers:{...(data?{'Content-Type':'application/json'}:{}),...(credential?{Authorization:`Bearer ${credential}`}:{})},body:data?JSON.stringify(data):undefined,signal:AbortSignal.timeout(20000)});
  const type=r.headers.get('content-type')||'';
  if(!type.includes('application/json')) throw Error(`Expected JSON at ${path}, status ${r.status}`);
  const body=await r.json(); if(!r.ok) throw Error(`${r.status}: ${body.error}`); return body;
}
const a=await call('/api/create',{name:'公网验证甲'});
sessions.push(a);
const b=await call('/api/join',{code:a.code,name:'公网验证乙'});
sessions.push(b);
const timer=setInterval(async()=>{if(polling)return;polling=true;try{await Promise.all(sessions.map(s=>call(`/api/state?code=${s.code}`,null,s.token)));}catch{}finally{polling=false;}},1500);
let rounds=0, actions=0;
try{
 async function action(i,action,rest={}){actions++;return call('/api/action',{code:a.code,action,...rest},sessions[i].token);}
 await action(0,'ready'); let s=await action(1,'ready');
 for(let n=0;n<700 && s.phase!=='finished';n++){
   if(s.phase==='rolling'){
     s=await action(s.turn,'roll');const p=s.players[s.turn];
     const held=p.dice.map(d=>d.gold||['axe','arrow','hand'].includes(d.symbol));
     s=await action(s.turn,'keep',{held});
   }else if(s.phase==='favor'){
     for(let i=0;i<2;i++){
       const p=s.players[i], other=s.players[1-i];
       const predicted=p.energy+p.dice.filter(d=>d.gold).length-other.dice.filter(d=>d.symbol==='hand').length;
       const level=predicted>=12?3:predicted>=8?2:predicted>=4?1:0;
       s=await action(i,'favor',{level});
     }
   }else if(s.phase==='result'){
     rounds=s.round; console.log(`第 ${rounds} 回合结算，生命 ${s.players.map(p=>p.hp).join(' / ')}`);
     await action(0,'ready');s=await action(1,'ready');
   }else throw Error(`Unexpected phase ${s.phase}`);
 }
 assert.equal(s.phase,'finished','No result within action limit');
 const states=await Promise.all(sessions.map(c=>call(`/api/state?code=${c.code}`,null,c.token)));
 assert.deepEqual(states[0].players,states[1].players);assert.deepEqual(states[0].log,states[1].log);assert.equal(states[0].winner,states[1].winner);
 const evidence={url:base,date:new Date().toISOString(),rounds:s.round,actions,phase:s.phase,winner:s.winner,health:s.players.map(p=>p.hp),synchronized:true};
writeFileSync(process.argv[3] || new URL('./verification/public-e2e.json',import.meta.url),JSON.stringify(evidence,null,2));
 console.log(JSON.stringify(evidence));
}finally{clearInterval(timer);}
