// 本机分享专用入口：只监听回环地址，再按需由隧道转发游戏服务。
import { createApp } from '../server.mjs';

const port = Number(process.env.FATE_LOCAL_PORT || 3100);
if (!Number.isInteger(port) || port < 1024 || port > 65535) {
  throw new Error('FATE_LOCAL_PORT 必须是 1024 至 65535 之间的整数');
}
const { server } = createApp();
server.on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? `本机端口 ${port} 已被占用，请选择其他端口。` : '本机游戏服务启动失败。');
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  console.log(`本机游戏：http://127.0.0.1:${port}`);
  console.log('仅监听本机。此入口本身不会创建公网链接。按 Ctrl+C 结束。');
});
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.once(signal, () => {
    server.close();
    server.closeAllConnections();
  });
}
