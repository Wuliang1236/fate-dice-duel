function randomInt(max) {
  const ceiling = Math.floor(0x100000000 / max) * max;
  const values = new Uint32Array(1);
  do { crypto.getRandomValues(values); } while (values[0] >= ceiling);
  return values[0] % max;
}

export const SYMBOLS = ['axe', 'axe', 'arrow', 'helmet', 'shield', 'hand'];
// 每枚骰子的两个固定带框面；两个斧头是不同的物理骰面。
export const GOLD_FACES = [[0, 5], [2, 3], [1, 4], [2, 5], [0, 3], [4, 5]];
export const FAVORS = [{ cost: 0, damage: 0 }, { cost: 4, damage: 2 }, { cost: 8, damage: 5 }, { cost: 12, damage: 8 }];
export const OFFLINE_MS = 6_000;
export const FORFEIT_MS = 60_000;
const check = (condition, message) => { if (!condition) throw new Error(message); };
export const token = () => Array.from(crypto.getRandomValues(new Uint8Array(24)), b => b.toString(16).padStart(2, '0')).join('');

export function player(name, now) {
  return { name: String(name || '旅人').trim().slice(0, 16) || '旅人', token: token(), hp: 15, energy: 0,
    dice: Array(6).fill(null), held: Array(6).fill(false), rolls: 0, favor: null, ready: false, lastSeen: now };
}
export function room(code, name, now = Date.now()) {
  return { code, players: [player(name, now)], phase: 'lobby', round: 0, first: 0, turn: 0,
    rolled: false, winner: null, log: [], createdAt: now, touchedAt: now };
}
function log(r, message) { r.log.push(message); r.log = r.log.slice(-100); }
export function nextRound(r) {
  r.round++;
  r.settlement = null;
  if (r.round > 1) r.first = 1 - r.first;
  r.turn = r.first; r.phase = 'rolling'; r.rolled = false;
  for (const p of r.players) {
    p.dice = Array(6).fill(null); p.held = Array(6).fill(false);
    p.rolls = 0; p.favor = null; p.ready = false;
  }
  log(r, `第 ${r.round} 回合 · ${r.players[r.first].name} 先手`);
}
function end(r, winner, reason) {
  r.phase = 'finished'; r.winner = winner;
  log(r, reason || (winner === -1 ? '双方同时倒下，本局平局。' : `${r.players[winner].name} 获胜。`));
}
function death(r) {
  const dead = r.players.map(p => p.hp <= 0);
  if (!dead.some(Boolean)) return false;
  end(r, dead.every(Boolean) ? -1 : dead[0] ? 1 : 0); return true;
}
export function presence(r, now = Date.now()) {
  if (r.players.length !== 2 || ['lobby', 'finished'].includes(r.phase)) return;
  const lost = r.players.map(p => now - p.lastSeen >= FORFEIT_MS);
  if (lost.every(Boolean)) end(r, -1, '双方离线超过 60 秒，对局结束。');
  else if (lost.some(Boolean)) {
    const winner = lost[0] ? 1 : 0;
    end(r, winner, `${r.players[1 - winner].name} 离线超过 60 秒，${r.players[winner].name} 获胜。`);
  }
}
export function settle(r) {
  const count = (p, s) => p.dice.filter(d => d.symbol === s).length;
  const snapshot = () => r.players.map(({ hp, energy }) => ({ hp, energy }));
  const settlement = { round: r.round, before: snapshot(), events: [] };
  r.settlement = settlement;
  const record = event => settlement.events.push({ ...event, after: snapshot() });
  for (const [i, p] of r.players.entries()) {
    const gain = p.dice.filter(d => d.gold).length;
    p.energy += gain; log(r, `${p.name} 从带框骰子获得 ${gain} 点能量。`);
    if (gain) record({ type: 'energy', player: i, dice: p.dice.flatMap((d, n) => d.gold ? [n] : []), amount: gain });
  }
  for (const i of [r.first, 1 - r.first]) {
    const p = r.players[i], other = r.players[1 - i];
    const n = Math.min(count(p, 'hand'), other.energy);
    p.energy += n; other.energy -= n;
    log(r, `${p.name} 偷取 ${n} 点能量。`);
    const hands = p.dice.flatMap((d, index) => d.symbol === 'hand' ? [index] : []);
    if (hands.length) record({ type: 'steal', player: i, dice: hands, amount: n });
  }
  const attacks = [];
  for (const [i, p] of r.players.entries()) {
    const defender = r.players[1 - i];
    for (const [symbol, shield] of [['axe', 'helmet'], ['arrow', 'shield']]) {
      const defenses = defender.dice.flatMap((d, index) => d.symbol === shield ? [index] : []);
      const weapons = p.dice.flatMap((d, index) => d.symbol === symbol ? [index] : []);
      weapons.forEach((index, n) => attacks.push({ player: i, die: index, symbol, blockedBy: defenses[n] ?? null }));
    }
  }
  const hits = r.players.map((p, i) => {
    const other = r.players[1 - i];
    return Math.max(0, count(p, 'axe') - count(other, 'helmet')) +
      Math.max(0, count(p, 'arrow') - count(other, 'shield'));
  });
  hits.forEach((n, i) => {
    r.players[1 - i].hp = Math.max(0, r.players[1 - i].hp - n);
    log(r, `${r.players[i].name} 的普通攻击造成 ${n} 点伤害。`);
  });
  if (attacks.length) record({ type: 'combat', attacks, damage: hits });
  if (death(r)) return;
  for (const i of [r.first, 1 - r.first]) {
    const p = r.players[i], f = FAVORS[p.favor];
    if (!f.cost) continue;
    if (p.energy < f.cost) {
      log(r, `${p.name} 能量不足，索尔怒袭未发动，不扣除能量。`);
      record({ type: 'fizzle', player: i, level: p.favor });
      continue;
    }
    p.energy -= f.cost;
    r.players[1 - i].hp = Math.max(0, r.players[1 - i].hp - f.damage);
    log(r, `${p.name} 消耗 ${f.cost} 点能量发动索尔怒袭，造成 ${f.damage} 点伤害。`);
    record({ type: 'favor', player: i, level: p.favor, cost: f.cost, damage: f.damage });
    if (death(r)) return;
  }
  r.phase = 'result';
}
export function act(r, who, action, data = {}, now = Date.now(), rng = randomInt) {
  presence(r, now);
  check(Number.isInteger(who) && r.players[who], '玩家不存在');
  const p = r.players[who];
  check(r.phase !== 'finished', '本局已结束');
  check(r.players.length === 2, '等待另一位玩家加入');
  check(r.players.every(x => now - x.lastSeen < OFFLINE_MS), '有玩家离线，对局已暂停');
  if (action === 'ready') {
    check(r.phase === 'lobby' || r.phase === 'result', '当前不能准备');
    p.ready = true;
    if (r.players.every(x => x.ready)) {
      if (!r.round) r.first = rng(2);
      nextRound(r);
    }
  } else if (action === 'roll') {
    check(r.phase === 'rolling' && r.turn === who && !r.rolled, '现在不能投骰');
    check(p.rolls < 3, '本回合投骰次数已用完');
    p.dice = p.dice.map((d, i) => {
      if (p.held[i]) return d;
      const face = rng(6);
      return { symbol: SYMBOLS[face], gold: GOLD_FACES[i].includes(face) };
    });
    p.rolls++; r.rolled = true;
  } else if (action === 'keep') {
    check(r.phase === 'rolling' && r.turn === who && r.rolled, '请先投骰');
    check(Array.isArray(data.held) && data.held.length === 6 && data.held.every(v => typeof v === 'boolean'), '保留骰子参数错误');
    p.held = p.rolls === 3 ? Array(6).fill(true) : [...data.held];
    r.rolled = false;
    if (r.players.every(x => x.rolls === 3)) r.phase = 'favor';
    else r.turn = 1 - who;
  } else if (action === 'favor') {
    check(r.phase === 'favor' && p.favor === null, '当前不能选择恩惠');
    check(Number.isInteger(data.level) && data.level >= 0 && data.level <= 3, '恩惠等级错误');
    p.favor = data.level;
    if (r.players.every(x => x.favor !== null)) settle(r);
  } else throw new Error('未知操作');
  r.touchedAt = now;
}
export function view(r, who, now = Date.now()) {
  presence(r, now);
  return { code: r.code, you: who, phase: r.phase, round: r.round, first: r.first, turn: r.turn,
    rolled: r.rolled, winner: r.winner, log: r.log,
    settlement: ['result', 'finished'].includes(r.phase) ? r.settlement ?? null : null,
    paused: r.phase !== 'finished' && r.players.some(p => now - p.lastSeen >= OFFLINE_MS),
    players: r.players.map((p, i) => ({
      name: p.name, hp: p.hp, energy: p.energy, dice: p.dice, held: p.held, rolls: p.rolls, ready: p.ready,
      favor: i === who || ['result', 'finished'].includes(r.phase) ? p.favor : null,
      favorChosen: p.favor !== null, online: now - p.lastSeen < OFFLINE_MS,
      reconnectSeconds: Math.max(0, Math.ceil((FORFEIT_MS - (now - p.lastSeen)) / 1000))
    })) };
}
