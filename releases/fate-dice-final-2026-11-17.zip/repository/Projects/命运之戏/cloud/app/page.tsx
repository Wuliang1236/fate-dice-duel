import markup from "./game-markup";
import GameLoader from "./game-loader";
export default function Home() {
  return <><div dangerouslySetInnerHTML={{ __html: markup }} /><GameLoader /></>;
}
