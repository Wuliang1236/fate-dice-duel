"use client";
import { useEffect } from "react";
export default function GameLoader() {
  useEffect(() => {
    if (document.getElementById("fate-game-script")) return;
    const script = document.createElement("script");
    script.id = "fate-game-script";
    script.type = "module";
    script.src = "/app.js";
    document.body.appendChild(script);
  }, []);
  return null;
}
