# 命运之戏 · Sites 云端版本

此目录部署至 Sites / Cloudflare Workers，使用 D1 保存房间。原有本地 Node.js 版本位于父目录。

## 同步与验证

在此目录执行 `node scripts/sync-game.mjs`，从父项目同步规则、界面及样式。生成的 lib/game.mjs、public/app.js、public/style.css 和 app/game-markup.ts 是发布所需源码的一部分，直接修改父项目后再同步。

- 规则与本地 HTTP 测试：父目录 `node --test test/game.test.mjs`，14 项通过。
- 云端 API 测试：此目录 `node --test test/api.test.mjs`，5 项通过，使用正式迁移 SQL 创建内存 SQLite 数据库，验证完整对局、并发加入、并发准备、重复投骰、身份、超时和限流。
- 构建：`node scripts/run-framework.mjs build`。本机 npm shim 存在路径错误时，使用 Node 执行 npm-cli.js 安装；依赖缓存指向忽略的 .sites-runtime/npm-cache。
- 数据库结构：db/schema.ts；已生成的 drizzle/0000_bored_chamber.sql 在首次发布时由 Sites 应用。后续修改生成新迁移，不修改已应用 SQL。

## 运行边界

每个请求从数据库读取房间，通过 revision 条件更新解决并发覆盖；单个 Worker 进程重启不丢失已保存房间。身份保存在玩家原标签页的会话存储中。无活动 30 分钟后房间失效；房间数据在创建或加入时清理。离线超过 60 秒按规则判负，数据库持久化不取消离线规则。

首次创建或加入每个连接地址每分钟最多 30 次；仅保存带分钟信息的 IP 哈希，额度记录两分钟后清理。最多约 200 个活跃房间，未做压力测试。

发布流程使用 Sites 技能提供的源码同步与打包工具；源码仓库属于此 Site。源码不包含原始参考图片、npm 缓存、预览数据库或访问凭证。

项目身份以 .openai/hosting.json 中 project_id 为准；继续工作时复用它，不重复创建 Site。
