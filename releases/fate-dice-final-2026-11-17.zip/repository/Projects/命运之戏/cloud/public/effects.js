// 仅播放服务端已经结算的事实，不参与判定。
const svg = {
  axe: '<path d="M9 29 24 5M18 7c8-1 12 3 11 9l-9-3M8 26l4 3"/>',
  arrow: '<path d="m7 28 21-21m-7 0h7v7M7 21v7h7"/>',
  hand: '<path d="m9 24-4-8q-1-3 2-2l5 4V8q0-4 3-1v9-12q2-3 3 0v12-10q3-3 3 1v10-7q3-2 3 2v11q-1 7-7 7h-2q-4 0-6-6Z"/>',
};
const icon = type => `<svg viewBox="0 0 34 34" aria-hidden="true">${svg[type]}</svg>`;
const bolt = '<svg viewBox="0 0 100 180" preserveAspectRatio="none" aria-hidden="true"><path fill="currentColor" fill-opacity=".8" d="M56 0 30 52 52 49 34 98 54 94 36 180 78 87 58 92 78 44 58 48 73 0 Z"/><path class="branch" d="M31 52 10 68 22 72 7 93M78 87 94 103 82 108 96 126M42 142 20 157"/></svg>';

export function playSettlement({ settlement, you, onSnapshot, onCaption, onDone, onSound = () => {}, onStop = () => {}, visual = true }) {
  const board = document.querySelector('.table');
  const layer = document.createElement('div');
  layer.className = 'effects-layer'; layer.setAttribute('aria-hidden', 'true');
  layer.style.visibility = visual ? 'visible' : 'hidden';
  board.append(layer);
  let stopped = false, finished = false;
  const applySnapshot = value => { if (!stopped) onSnapshot(value); };
  const active = new Set();
  let pendingWake = null;
  const panel = player => document.getElementById(player === you ? 'self' : 'opponent');
  const element = (player, selector) => panel(player)?.querySelector(selector);
  const center = el => {
    if (!el) return null;
    const a = el.getBoundingClientRect(), b = board.getBoundingClientRect();
    return { x: a.left + a.width / 2 - b.left, y: a.top + a.height / 2 - b.top };
  };
  const node = (className, html = '') => {
    const el = document.createElement('div'); el.className = `effect-object ${className}`;
    el.innerHTML = html; layer.append(el); return el;
  };
  const move = (el, frames, options) => {
    if (stopped) { el.remove(); return Promise.resolve(); }
    try {
      const animation = el.animate(frames, { fill: 'both', easing: 'ease-in-out', ...options });
      active.add(animation);
      return animation.finished.catch(() => {}).finally(() => { active.delete(animation); el.remove(); });
    } catch { el.remove(); return Promise.resolve(); }
  };
  const wait = ms => new Promise(resolve => {
    if (stopped) return resolve();
    const id = setTimeout(() => { pendingWake = null; resolve(); }, ms);
    pendingWake = () => { clearTimeout(id); pendingWake = null; resolve(); };
  });
  const fly = (type, from, to, delay = 0, duration = 650, extra = '') => {
    if (!from || !to || stopped) return Promise.resolve();
    const el = node(`effect-${type} ${extra}`, svg[type] ? icon(type) : type === 'token' ? '⌘' : '');
    const half = type === 'mote' ? 4 : type === 'token' ? 12 : 15;
    const point = p => `translate(${p.x - half}px,${p.y - half}px)`;
    const rotate = type === 'axe' ? ' rotate(340deg)' : type === 'arrow' ? ` rotate(${Math.atan2(to.y - from.y, to.x - from.x) * 180 / Math.PI - 45}deg)` : '';
    return move(el, [{ transform: point(from), opacity: 0 }, { opacity: 1, offset: .14 },
      { transform: point(to) + rotate, opacity: .95 }], { duration, delay, easing: 'cubic-bezier(.25,.1,.4,1)' });
  };
  const burst = (point, kind = '', label = '') => {
    if (!point || stopped) return Promise.resolve();
    const ring = node(`effect-impact ${kind}`);
    const tasks = [move(ring, [{ transform: `translate(${point.x - 30}px,${point.y - 30}px) scale(.25)`, opacity: .9 },
      { transform: `translate(${point.x - 30}px,${point.y - 30}px) scale(1.25)`, opacity: 0 }], { duration: 500 })];
    if (label) {
      const message = node(`effect-label ${kind === 'hit' ? 'hurt' : ''}`); message.textContent = label;
      tasks.push(move(message, [{ transform: `translate(${point.x - 18}px,${point.y - 20}px)`, opacity: 1 },
        { transform: `translate(${point.x - 18}px,${point.y - 49}px)`, opacity: 0 }], { duration: 700 }));
    }
    return Promise.all(tasks);
  };
  const dicePoint = (player, index) => center(element(player, `.dice-row .die:nth-child(${index + 1})`));
  const energyPoint = player => center(element(player, '.stats .energy'));
  const lifePoint = player => center(element(player, '.lives'));
  const finish = (cancelled = false) => {
    if (finished) return;
    finished = true; stopped = true;
    if (cancelled) onStop();
    if (pendingWake) pendingWake();
    for (const a of active) a.cancel();
    layer.remove(); onDone();
  };
  async function run() {
    try {
      applySnapshot(settlement.before);
      for (const event of settlement.events) {
        if (stopped) break;
        if (event.type === 'energy') {
          onCaption('金色符文汇聚能量'); onSound('energy');
          const target = energyPoint(event.player);
          await Promise.all(event.dice.flatMap((index, i) => [0, 1, 2].map((particle, n) => {
            const source = dicePoint(event.player, index);
            return fly('mote', source && { x: source.x + (n - 1) * 8, y: source.y + (particle - 1) * 6 }, target, i * 50 + n * 45, 620);
          })));
          applySnapshot(event.after); await burst(target, '', `+${event.amount} 能量`);
        } else if (event.type === 'steal') {
          onCaption(event.amount ? '手套伸向对手，夺取能量' : '手套落空，对手没有能量'); onSound('hand');
          const target = energyPoint(1 - event.player), source = energyPoint(event.player);
          await Promise.all(event.dice.map((index, i) => fly('hand', dicePoint(event.player, index), target, i * 45, 620)));
          await Promise.all(event.dice.slice(0, event.amount).map((_, i) => fly('token', target, source, i * 60, 560)));
          applySnapshot(event.after); await burst(target, '', event.amount ? `−${event.amount} 能量` : '没有能量');
        } else if (event.type === 'combat') {
          onCaption('斧与箭同时出击');
          if (event.attacks.some(attack => attack.symbol === 'axe')) onSound('axe');
          if (event.attacks.some(attack => attack.symbol === 'arrow')) onSound('arrow');
          const impacts = [];
          await Promise.all(event.attacks.map((attack, i) => {
            const target = attack.blockedBy === null ? lifePoint(1 - attack.player) : dicePoint(1 - attack.player, attack.blockedBy);
            impacts.push({ point: target, kind: attack.blockedBy === null ? 'hit' : 'block' });
            return fly(attack.symbol, dicePoint(attack.player, attack.die), target, (i % 3) * 75, 680, 'effect-weapon');
          }));
          if (impacts.some(impact => impact.kind === 'block')) onSound('block');
          if (impacts.some(impact => impact.kind === 'hit')) onSound('hit');
          applySnapshot(event.after);
          await Promise.all(impacts.map(({ point, kind }) => burst(point, kind)));
          await Promise.all(event.damage.map((amount, player) => amount ? burst(lifePoint(1 - player), 'hit', `−${amount} 生命`) : Promise.resolve()));
        } else if (event.type === 'favor') {
          onCaption(`索尔怒袭 · 消耗 ${event.cost} 能量`); onSound('thunder', event.level);
          const target = lifePoint(1 - event.player);
          if (target) {
            const lightning = node(`effect-bolt level-${event.level}`, bolt);
            const height = event.level === 3 ? 260 : event.level === 2 ? 220 : 185;
            lightning.style.height = `${height}px`;
            const width = event.level === 3 ? 148 : event.level === 2 ? 112 : 84;
            await move(lightning, [{ transform: `translate(${target.x - width / 2}px,${target.y - height}px) scale(.85)`, opacity: 0 },
              { opacity: 1, offset: .25 }, { opacity: .55, offset: .45 }, { opacity: 1, offset: .6 },
              { transform: `translate(${target.x - width / 2}px,${target.y - height}px) scale(1.05)`, opacity: 0 }], { duration: 1400 });
          }
          applySnapshot(event.after); await burst(target, 'hit', `−${event.damage} 生命`);
        } else if (event.type === 'fizzle') {
          onCaption('能量不足，索尔怒袭未发动'); onSound('fizzle');
          await burst(energyPoint(event.player), '', '能量不足'); applySnapshot(event.after);
        }
        await wait(120);
      }
    } catch (error) {
      console.error('结算动画未能完整播放', error);
    } finally { finish(); }
  }
  // 开始前先返回控制句柄，避免无动画步骤同步结束。
  Promise.resolve().then(run);
  return { skip: () => finish(true), setVisual(value) { layer.style.visibility = value ? 'visible' : 'hidden'; } };
}
