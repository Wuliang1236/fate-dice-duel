// 使用浏览器合成短音效，不下载音频文件；播放必须先经过玩家操作。
export function createAudioController(browser = window) {
  let context = null, master = null, noiseBuffer = null, enabled = true;
  const sources = new Set();
  function activate() {
    if (!enabled) return;
    try {
      const Audio = browser.AudioContext || browser.webkitAudioContext;
      if (!Audio) return;
      if (!context) {
        context = new Audio();
        master = context.createGain(); master.gain.value = .55; master.connect(context.destination);
      }
      if (context.state !== 'running' && context.state !== 'closed') context.resume().catch(() => {});
    } catch { /* 不支持音频或浏览器拒绝时，游戏仍可正常进行。 */ }
  }
  browser.addEventListener('pointerdown', activate, { passive: true });
  browser.addEventListener('keydown', activate);
  function envelope(node, start, duration, volume) {
    node.gain.setValueAtTime(.0001, start);
    node.gain.exponentialRampToValueAtTime(Math.max(.0002, volume), start + .015);
    node.gain.exponentialRampToValueAtTime(.0001, start + duration);
  }
  function track(source) { sources.add(source); source.onended = () => sources.delete(source); }
  function tone(wave, startHz, endHz, duration, volume, delay = 0) {
    const start = context.currentTime + delay;
    const osc = context.createOscillator(), gain = context.createGain();
    osc.type = wave; osc.frequency.setValueAtTime(startHz, start);
    osc.frequency.exponentialRampToValueAtTime(endHz, start + duration);
    envelope(gain, start, duration, volume); osc.connect(gain); gain.connect(master);
    track(osc); osc.start(start); osc.stop(start + duration + .02);
  }
  function noise(duration, volume, filterType, startHz, endHz, delay = 0) {
    if (!noiseBuffer) {
      noiseBuffer = context.createBuffer(1, Math.ceil(context.sampleRate * 1.6), context.sampleRate);
      const channel = noiseBuffer.getChannelData(0);
      for (let i = 0; i < channel.length; i++) channel[i] = (Math.random() * 2 - 1) * .6;
    }
    const start = context.currentTime + delay;
    const source = context.createBufferSource(), filter = context.createBiquadFilter(), gain = context.createGain();
    source.buffer = noiseBuffer; filter.type = filterType;
    filter.frequency.setValueAtTime(startHz, start);
    filter.frequency.exponentialRampToValueAtTime(endHz, start + duration);
    envelope(gain, start, duration, volume); source.connect(filter); filter.connect(gain); gain.connect(master);
    track(source); source.start(start); source.stop(start + duration + .02);
  }
  function stop() {
    for (const source of sources) { try { source.stop(); } catch {} }
    sources.clear();
  }
  function play(kind, level = 1) {
    if (!enabled || !context || context.state !== 'running') return;
    try {
      if (kind === 'energy') {
        tone('sine', 660, 1000, .24, .06);
        tone('sine', 850, 1260, .19, .045, .09);
        tone('sine', 1100, 1500, .16, .035, .17);
      } else if (kind === 'hand') {
        tone('sine', 230, 370, .24, .045); noise(.18, .025, 'bandpass', 500, 950);
      } else if (kind === 'axe') {
        noise(.28, .055, 'bandpass', 700, 2200); tone('sine', 250, 130, .2, .025);
      } else if (kind === 'arrow') {
        noise(.22, .045, 'highpass', 1500, 2600); tone('sine', 760, 1150, .14, .025);
      } else if (kind === 'block') {
        tone('triangle', 950, 640, .25, .06); tone('sine', 1450, 1000, .17, .035);
      } else if (kind === 'hit') {
        noise(.2, .085, 'lowpass', 1000, 160); tone('sine', 120, 50, .3, .09);
      } else if (kind === 'fizzle') {
        tone('sine', 330, 160, .3, .04);
      } else if (kind === 'thunder') {
        const intensity = Math.min(3, Math.max(1, Number(level) || 1));
        const duration = [.55, .85, 1.3][intensity - 1];
        noise(.12, .045 + intensity * .012, 'highpass', 3500, 1100);
        noise(duration, .09 + intensity * .025, 'lowpass', 950, 110);
        tone('sine', 100, 38, duration, .07 + intensity * .018);
      }
    } catch { /* 个别音效失败时不影响结算。 */ }
  }
  return { play, stop, activate, setEnabled(value) { enabled = Boolean(value); if (!enabled) stop(); } };
}
