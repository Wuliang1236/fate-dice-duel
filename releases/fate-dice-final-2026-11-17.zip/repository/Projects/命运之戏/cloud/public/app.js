import { playSettlement } from './effects.js';
import { createAudioController } from './audio.js';
const $ = id => document.getElementById(id);
const paths = {
  axe: '<path d="M9 29 24 5M18 7c8-1 12 3 11 9l-9-3M8 26l4 3"/>',
  arrow: '<path d="m7 28 21-21m-7 0h7v7M7 21v7h7"/>',
  helmet: '<path d="M7 19v-5a10 10 0 0 1 20 0v5M5 19h24M11 20v9l6-5 6 5v-9M17 4v13"/>',
  shield: '<circle cx="17" cy="17" r="13"/><circle cx="17" cy="17" r="9"/><circle cx="17" cy="17" r="2"/>',
  hand: '<path d="m9 24-4-8q-1-3 2-2l5 4V8q0-4 3-1v9-12q2-3 3 0v12-10q3-3 3 1v10-7q3-2 3 2v11q-1 7-7 7h-2q-4 0-6-6Z"/>',
};
const names = { axe: '斧头', arrow: '箭矢', helmet: '头盔', shield: '圆盾', hand: '手套' };
const icon = type => `<svg viewBox="0 0 34 34" aria-hidden="true">${paths[type] || ''}</svg>`;
function dieHTML(d, held = false) {
  return d ? `${icon(d.symbol)}<small>${names[d.symbol]}</small>` : 'ᛟ';
}
function decorativeDie(type, gold) {
  return `<div class="die ${gold ? 'gold' : ''}">${dieHTML({ symbol: type, gold })}</div>`;
}
$('hero-dice').innerHTML = ['axe', 'shield', 'hand', 'arrow', 'helmet', 'axe'].map((s, i) => decorativeDie(s, i % 2 === 0)).join('');
$('hero-stones').innerHTML = '<span class="stone"></span>'.repeat(15);
const guide = { axe: '造成 1 点近战伤害', arrow: '造成 1 点远程伤害', helmet: '抵消 1 点斧头伤害', shield: '抵消 1 点箭矢伤害', hand: '偷取对手 1 点能量' };
$('symbol-guide').innerHTML = Object.entries(guide).map(([s, desc]) => `<div>${icon(s)}<p><strong>${names[s]}</strong><br>${desc}</p></div>`).join('') + '<div><strong>⌘</strong><p><strong>金色虚线框</strong><br>结算时获得 1 点能量</p></div>';
$('rules-open').onclick = () => $('rules').showModal();
$('rules-close').onclick = () => $('rules').close();
let session = null, state = null, held = [], selectionKey = '', busy = false, polling = false, networkDown = false, toastTimer;
let playing = null;
const playedSettlements = new Set();
const sounds = createAudioController();
let soundEnabled = true;
let effectsEnabled = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
try {
  const choice = localStorage.getItem('fate-effects');
  if (choice !== null) effectsEnabled = choice === 'on';
  const soundChoice = localStorage.getItem('fate-sound');
  if (soundChoice !== null) soundEnabled = soundChoice === 'on';
} catch {}
function updateEffectsToggle() {
  $('effects-toggle').textContent = `特效：${effectsEnabled ? '开' : '关'}`;
  $('effects-toggle').setAttribute('aria-pressed', String(effectsEnabled));
}
function updateSoundToggle() {
  $('sound-toggle').textContent = `声音：${soundEnabled ? '开' : '关'}`;
  $('sound-toggle').setAttribute('aria-pressed', String(soundEnabled));
  sounds.setEnabled(soundEnabled);
}
updateEffectsToggle(); updateSoundToggle();
$('sound-toggle').onclick = () => {
  soundEnabled = !soundEnabled;
  try { localStorage.setItem('fate-sound', soundEnabled ? 'on' : 'off'); } catch {}
  updateSoundToggle();
  if (soundEnabled) sounds.activate();
  if (!soundEnabled && !effectsEnabled && playing) playing.handle.skip();
};
$('effects-toggle').onclick = () => {
  effectsEnabled = !effectsEnabled;
  try { localStorage.setItem('fate-effects', effectsEnabled ? 'on' : 'off'); } catch {}
  updateEffectsToggle();
  if (playing) {
    playing.handle.setVisual(effectsEnabled);
    if (!effectsEnabled && !soundEnabled) playing.handle.skip();
  }
};
const invite = new URL(location.href).searchParams.get('room')?.toUpperCase();
if (invite) $('room-code').value = invite;
try {
  const saved = JSON.parse(sessionStorage.getItem('fate-session') || 'null');
  if (saved && (!invite || saved.code === invite)) session = saved;
} catch { /* 浏览器禁用存储时仍可在当前页面游玩。 */ }
function toast(message) {
  $('toast').textContent = message; $('toast').hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').hidden = true; }, 5000);
}
async function api(path, data, auth = true) {
  const headers = {};
  if (auth && session) headers.Authorization = `Bearer ${session.token}`;
  if (data) headers['Content-Type'] = 'application/json';
  const response = await fetch(path, { method: data ? 'POST' : 'GET', headers,
    body: data ? JSON.stringify(data) : undefined, signal: AbortSignal.timeout(7000) });
  const result = await response.json();
  if (!response.ok) { const error = new Error(result.error || '连接失败'); error.status = response.status; throw error; }
  return result;
}
function enter(s) {
  session = s;
  try { sessionStorage.setItem('fate-session', JSON.stringify(s)); } catch {}
  history.replaceState(null, '', `?room=${s.code}`);
  $('landing').hidden = true; $('game').hidden = false;
  $('room-label').textContent = s.code; $('status-title').textContent = '正在连接命运之桌…';
  poll();
}
async function connect(kind) {
  if (busy) return;
  busy = true; $('create').disabled = true; $('join-form').querySelector('button').disabled = true;
  try {
    const s = await api(`/api/${kind}`, { name: $('nickname').value, code: $('room-code').value.trim().toUpperCase() }, false);
    enter(s);
  } catch (e) { toast(e.message); }
  finally { busy = false; $('create').disabled = false; $('join-form').querySelector('button').disabled = false; }
}
$('create').onclick = () => connect('create');
$('join-form').onsubmit = e => { e.preventDefault(); connect('join'); };
$('copy-link').onclick = async () => {
  const link = `${location.origin}/?room=${session.code}`;
  try { await navigator.clipboard.writeText(link); toast('邀请链接已复制，发给你的对手吧'); }
  catch { window.prompt('复制邀请链接', link); }
};
function clearSession() {
  if (playing) playing.handle.skip();
  playedSettlements.clear(); selectionKey = '';
  session = null; state = null;
  try { sessionStorage.removeItem('fate-session'); } catch {}
  $('game').hidden = true; $('landing').hidden = false; history.replaceState(null, '', '/');
}
async function poll() {
  if (!session || polling || busy) return;
  polling = true;
  try {
    state = await api(`/api/state?code=${session.code}`); networkDown = false; render();
  } catch (e) {
    if ([401, 404].includes(e.status)) { clearSession(); toast(e.message); }
    else { networkDown = true; if (state) render(); else { $('status-title').textContent = '暂时无法连接'; $('status-copy').textContent = '正在自动重试，请检查网络。'; } }
  } finally { polling = false; }
}
setInterval(poll, 1000);
async function action(type, extra = {}) {
  if (busy || networkDown) return;
  while (polling) await new Promise(resolve => setTimeout(resolve, 30));
  if (!session || busy || networkDown) return;
  busy = true; render();
  try { state = await api('/api/action', { code: session.code, action: type, ...extra }); render(); }
  catch (e) { toast(e.message); }
  finally { busy = false; render(); }
}
function button(label, fn, className = 'primary', disabled = false) {
  const b = document.createElement('button'); b.textContent = label; b.className = className;
  b.disabled = disabled || busy || networkDown || state.paused; b.onclick = fn; return b;
}
function panel(id, p, mine) {
  const el = $(id); el.replaceChildren();
  if (!p) { const x = document.createElement('div'); x.className = 'waiting-slot'; x.textContent = '虚位以待 · 邀请一位朋友入座'; el.append(x); return; }
  const header = document.createElement('div'); header.className = 'player-header';
  const title = document.createElement('div'); title.className = 'player-name'; title.textContent = p.name;
  const small = document.createElement('small'); small.textContent = `${mine ? '你' : '对手'} · ${p.online ? '在线' : '离线'}`; title.append(small);
  const stats = document.createElement('div'); stats.className = 'stats';
  stats.innerHTML = `<span class="health">生命 <b>${p.hp}</b><small> / 15</small></span><span class="energy">⌘ <b>${p.energy}</b></span>`;
  header.append(title, stats); el.append(header);
  const lives = document.createElement('div'); lives.className = 'lives'; lives.setAttribute('aria-label', `剩余 ${p.hp} 点生命`);
  lives.innerHTML = Array.from({ length: 15 }, (_, i) => `<span class="stone ${i >= p.hp ? 'empty' : ''}"></span>`).join(''); el.append(lives);
  const row = document.createElement('div'); row.className = 'dice-row';
  const canPick = mine && state.phase === 'rolling' && state.turn === state.you && state.rolled && p.rolls < 3 && !state.paused && !busy && !networkDown;
  p.dice.forEach((d, i) => {
    const picked = mine ? held[i] : p.held[i];
    const b = document.createElement('button'); b.className = `die ${d?.gold ? 'gold' : ''} ${d ? '' : 'unknown'} ${picked && d ? 'held' : ''}`;
    b.innerHTML = dieHTML(d, picked); b.disabled = !canPick; b.setAttribute('aria-pressed', String(!!picked));
    b.setAttribute('aria-label', d ? `第 ${i + 1} 枚，${names[d.symbol]}${d.gold ? '，带能量框' : ''}${picked ? '，已保留' : ''}` : '尚未投掷');
    b.onclick = () => { held[i] = !held[i]; panel('self', p, true); };
    row.append(b);
  });
  el.append(row);
}
function render() {
  if (!state || !session) return;
  if (playing) {
    if (playing.code === state.code && playing.round === state.round && state.settlement) return;
    const old = playing; playing = null; old.handle.skip();
  }
  const s = state, me = s.players[s.you], other = s.players[1 - s.you];
  const settlementKey = `${s.code}:${s.round}`;
  const animateSettlement = (effectsEnabled || soundEnabled) && s.settlement?.events?.length > 0 &&
    s.settlement.round === s.round && ['result', 'finished'].includes(s.phase) && !playedSettlements.has(settlementKey);
  const displayed = animateSettlement ? s.players.map((p, i) => ({ ...p, ...s.settlement.before[i] })) : s.players;
  const key = `${s.round}-${me.rolls}-${s.turn}-${s.rolled}-${s.phase}`;
  if (selectionKey !== key) { held = [...me.held]; if (me.rolls === 3) held.fill(true); selectionKey = key; }
  $('landing').hidden = true; $('game').hidden = false; $('room-label').textContent = s.code;
  $('round-label').textContent = s.round ? `第 ${String(s.round).padStart(2, '0')} 回合` : '等待入座';
  $('connection').textContent = networkDown ? '连接中断 · 重试中' : '已连接命运之桌';
  $('offline').hidden = !networkDown && !s.paused;
  $('offline').textContent = networkDown ? '网络连接中断，操作已暂停。正在自动重连；60 秒内恢复可继续对局。' :
    `对手暂时离线，对局已暂停。等待重连，剩余 ${other?.reconnectSeconds ?? 60} 秒。`;
  panel('self', displayed[s.you], true); panel('opponent', displayed[1 - s.you], false);
  for (const [id, phases] of [['phase-roll', ['rolling']], ['phase-favor', ['favor']], ['phase-result', ['result', 'finished']]]) $(id).classList.toggle('active', phases.includes(s.phase));
  let title = '', copy = '';
  const controls = $('controls'); controls.replaceChildren();
  if (s.phase === 'lobby') {
    title = other ? '两位旅人已入座' : '等待另一位旅人';
    copy = other ? '双方准备后，随机决定第一回合先手。' : '复制邀请链接，或让朋友输入房间码加入。';
    if (other) controls.append(button(me.ready ? '已准备 · 等待对手' : '准备开局', () => action('ready'), 'primary', me.ready));
  } else if (s.phase === 'rolling') {
    const myTurn = s.turn === s.you;
    title = myTurn ? s.rolled ? '选择你要留下的命运' : '轮到你投骰' : '对手正在选择命运';
    copy = myTurn ? s.rolled ? me.rolls === 3 ? '第三次投掷，所有骰子必须锁定。' : '点击骰子保留或取消保留，确认后交给对手。' : `这是你的第 ${me.rolls + 1} / 3 次投掷，已保留的骰子不会重掷。` : '观察对手的攻防，准备下一次选择。';
    if (myTurn) controls.append(s.rolled ? button('确认骰子 →', () => action('keep', { held: [...held] })) :
      button(`投掷骰子 · ${me.rolls + 1}/3`, () => action('roll')));
  } else if (s.phase === 'favor') {
    title = me.favorChosen ? '恩惠已选定' : '向众神献上你的选择';
    copy = me.favorChosen ? '等待对手提交，随后自动结算。' : '在恩惠面板选择等级，或保留能量。双方选择互相隐藏。';
    if (!me.favorChosen) controls.append(button('本回合不使用恩惠', () => action('favor', { level: 0 }), 'secondary'));
  } else if (s.phase === 'result') {
    title = '命运暂时落定'; copy = '查看右侧记录，双方确认后进入下一回合。';
    controls.append(button(me.ready ? '已确认 · 等待对手' : '下一回合 →', () => action('ready'), 'primary', me.ready));
  } else {
    title = s.winner === -1 ? '势均力敌 · 平局' : s.winner === s.you ? '这一次，命运站在你这边' : '胜负已定，故事未完';
    copy = s.winner === -1 ? '本局已结束。' : `${s.players[s.winner].name} 赢得了这场对决。`;
    const b = document.createElement('button'); b.textContent = '返回大厅'; b.className = 'primary'; b.onclick = clearSession; controls.append(b);
  }
  $('status-title').textContent = title; $('status-copy').textContent = copy;
  const options = $('favor-options'); options.replaceChildren();
  [4, 8, 12].forEach((cost, i) => {
    const b = button(`⌘ ${cost} 能量 → ${[2, 5, 8][i]} 伤害`, () => action('favor', { level: i + 1 }),
      `favor-option ${me.favor === i + 1 ? 'selected' : ''}`, s.phase !== 'favor' || me.favorChosen);
    options.append(b);
  });
  // 本回合完整记录在动画结束后展示，避免提前透露伤害和恩惠结果。
  const roundMarker = `第 ${s.round} 回合 · `;
  const roundStart = s.log.findLastIndex(line => line.startsWith(roundMarker));
  const visibleLog = animateSettlement && roundStart >= 0 ? s.log.slice(0, roundStart + 1) : s.log;
  const signature = JSON.stringify(visibleLog);
  if ($('log').dataset.signature !== signature) {
    $('log').dataset.signature = signature;
    $('log').replaceChildren(...(visibleLog.length ? [...visibleLog].reverse() : ['等待开局，传说即将开始。']).map(message => {
      const li = document.createElement('li'); li.textContent = message; return li;
    }));
  }
  if (animateSettlement) {
    playedSettlements.add(settlementKey);
    $('status-title').textContent = '命运正在结算';
    $('status-copy').textContent = '正在呈现本回合的攻防和恩惠。';
    controls.replaceChildren();
    const skip = document.createElement('button'); skip.className = 'secondary'; skip.textContent = '跳过结算动画';
    skip.onclick = () => playing?.handle.skip(); controls.append(skip);
    const entry = { code: s.code, round: s.round, handle: null };
    playing = entry;
    entry.handle = playSettlement({ settlement: s.settlement, you: s.you, visual: effectsEnabled,
      onSound: (kind, level) => sounds.play(kind, level), onStop: () => sounds.stop(),
      onCaption: caption => { $('status-copy').textContent = caption; },
      onSnapshot: snapshots => snapshots.forEach((values, i) => {
        const el = $(i === s.you ? 'self' : 'opponent');
        const health = el.querySelector('.health b'), energy = el.querySelector('.energy b'), lives = el.querySelector('.lives');
        if (health) health.textContent = values.hp;
        if (energy) energy.textContent = values.energy;
        if (lives) {
          lives.setAttribute('aria-label', `剩余 ${values.hp} 点生命`);
          lives.querySelectorAll('.stone').forEach((stone, n) => stone.classList.toggle('empty', n >= values.hp));
        }
      }),
      onDone: () => { if (playing === entry) { playing = null; render(); } }
    });
  }
}
if (session) enter(session);
