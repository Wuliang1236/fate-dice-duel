# 资源索引

三张参考图按原文件名保存在仓库根目录，保持原工程 README 中 ../../ 相对路径有效：

- ../2fef717a6389bc3ede177e4b278da49b94565ed97d22832c6a1f738361bec1c1.png
- ../372420ed1be6710506e977b8892880f209038105fe4d490bd20ef4ac781feaf5.png
- ../c0274444c2366ab5901630887976a9eb4cd14eaa476cfcbdd7724a11241d6161.png

截图位于 Projects/命运之戏/.agent-state/verification/：home.png、desktop-game.png、mobile-game.png、雷电动画演示.png。它们是历史实际截屏，未为本次归档重新渲染；雷电画面仅代表截屏时刻。

图标使用源代码内的 SVG 路径；动画使用 effects.js 和 CSS；音效由 audio.js 通过 Web Audio 实时合成，没有独立录音文件。原始参考图的来源授权未另行核验，仅用于用户自己的私有归档。
