import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "命运之戏 · 双人骰子对决",
  description: "掷下骰子，呼唤众神。两人实时在线骰子桌游。",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <head><link rel="stylesheet" href="/style.css" /><meta name="theme-color" content="#131b1b" /></head>
      <body>{children}</body>
    </html>
  );
}
