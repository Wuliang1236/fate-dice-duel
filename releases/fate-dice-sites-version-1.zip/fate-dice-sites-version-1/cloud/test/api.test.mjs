import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { handle } from '../lib/api.mjs';

function database() {
  const sqlite = new DatabaseSync(':memory:');
  const dir = new URL('../drizzle/', import.meta.url);
  for (const name of readdirSync(dir).filter(n => n.endsWith('.sql')).sort()) {
    sqlite.exec(readFileSync(new URL(name, dir), 'utf8'));
  }
  return {
    sqlite,
    prepare(sql) {
      return { bind(...values) {
        const statement = sqlite.prepare(sql);
        return {
          async first() { return statement.get(...values) || null; },
          async run() { return { meta: { changes: Number(statement.run(...values).changes) } }; }
        };
      } };
    }
  };
}
function client(db, clock = () => 1000) {
  return async (kind, body, credential, extraHeaders = {}) => {
    const req = new Request(`https://fate.example/api/${kind}${kind === 'state' ? `?code=${body.code}` : ''}`, {
      method: kind === 'state' ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json', ...(credential ? { Authorization: `Bearer ${credential}` } : {}), ...extraHeaders },
      ...(kind === 'state' ? {} : { body: JSON.stringify(body) }),
    });
    const response = await handle(req, db, { now: clock(), rng: () => 0 });
    return { status: response.status, data: await response.json() };
  };
}
test('数据库版本完整对局：两客户端同步投骰、恩惠和最终胜负', async t => {
  const db = database(); t.after(() => db.sqlite.close()); const call = client(db);
  const a = (await call('create', { name: '甲' })).data;
  const b = (await call('join', { code: a.code, name: '乙' })).data;
  const credentials = [a.token, b.token];
  async function act(i, action, rest = {}) {
    const v = await call('action', { code: a.code, action, ...rest }, credentials[i]);
    assert.equal(v.status, 200, v.data.error); return v.data;
  }
  await act(0, 'ready'); let s = await act(1, 'ready');
  for (let i = 0; i < 100 && s.phase !== 'finished'; i++) {
    if (s.phase === 'rolling') { await act(s.turn, 'roll'); s = await act(s.turn, 'keep', { held: Array(6).fill(false) }); }
    else if (s.phase === 'favor') { await act(0, 'favor', { level: 0 }); s = await act(1, 'favor', { level: 0 }); }
    else { await act(0, 'ready'); s = await act(1, 'ready'); }
  }
  assert.equal(s.phase, 'finished'); assert.equal(s.winner, -1);
  const other = (await call('state', { code: a.code }, a.token)).data;
  assert.deepEqual(other.players, s.players); assert.deepEqual(other.log, s.log);
});
test('并发加入仅一人成功，并发准备不会丢失其中一人的操作', async t => {
  const db = database(); t.after(() => db.sqlite.close()); const call = client(db);
  const a = (await call('create', { name: '甲' })).data;
  const joining = await Promise.all([call('join', { code: a.code, name: '乙' }), call('join', { code: a.code, name: '丙' })]);
  assert.deepEqual(joining.map(x => x.status).sort(), [200, 409]);
  const b = joining.find(x => x.status === 200).data;
  const ready = await Promise.all([call('action', { code: a.code, action: 'ready' }, a.token), call('action', { code: a.code, action: 'ready' }, b.token)]);
  assert.ok(ready.every(x => x.status === 200));
  const s = (await call('state', { code: a.code }, a.token)).data;
  assert.equal(s.phase, 'rolling'); assert.equal(s.round, 1);
});
test('两个同时投骰请求不会让同一玩家多投一次', async t => {
  const db = database(); t.after(() => db.sqlite.close()); const call = client(db);
  const a = (await call('create', {})).data;
  const b = (await call('join', { code: a.code })).data;
  await call('action', { code: a.code, action: 'ready' }, a.token);
  await call('action', { code: a.code, action: 'ready' }, b.token);
  const results = await Promise.all([0, 1].map(() => call('action', { code: a.code, action: 'roll' }, a.token)));
  assert.deepEqual(results.map(x => x.status).sort(), [200, 409]);
  const s = (await call('state', { code: a.code }, a.token)).data;
  assert.equal(s.players[0].rolls, 1);
});
test('请求之间不依赖内存；身份校验、超时判负及过期回收', async t => {
  const db = database(); t.after(() => db.sqlite.close()); let time = 1000;
  let call = client(db, () => time);
  const a = (await call('create', {})).data, b = (await call('join', { code: a.code })).data;
  await call('action', { code: a.code, action: 'ready' }, a.token);
  await call('action', { code: a.code, action: 'ready' }, b.token);
  assert.equal((await call('state', { code: a.code }, 'fake')).status, 401);
  call = client(db, () => time);
  time = 59000; await call('state', { code: a.code }, b.token);
  time = 61000;
  const v = await call('state', { code: a.code }, a.token);
  assert.equal(v.data.phase, 'finished'); assert.equal(v.data.winner, 1);
  assert.ok(!JSON.stringify(v.data).includes(a.token));
  time += 31 * 60_000;
  assert.equal((await call('state', { code: a.code }, a.token)).status, 404);
});
test('跨站、非法参数和创建滥用被拒绝', async t => {
  const db = database(); t.after(() => db.sqlite.close()); const call = client(db);
  assert.equal((await call('create', {}, null, { Origin: 'https://evil.example' })).status, 403);
  assert.equal((await call('create', [])).status, 400);
  for (let i = 0; i < 30; i++) assert.equal((await call('create', {})).status, 201);
  assert.equal((await call('create', {})).status, 429);
});
