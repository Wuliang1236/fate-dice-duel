CREATE TABLE `fate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `fate_limits_expiry` ON `fate_limits` (`expires_at`);--> statement-breakpoint
CREATE TABLE `fate_rooms` (
	`code` text PRIMARY KEY NOT NULL,
	`state` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `fate_rooms_expiry` ON `fate_rooms` (`expires_at`);