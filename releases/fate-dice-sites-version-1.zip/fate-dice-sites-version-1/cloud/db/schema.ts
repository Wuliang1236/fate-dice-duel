import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";
export const rooms = sqliteTable("fate_rooms", {
  code: text("code").primaryKey(),
  state: text("state").notNull(),
  revision: integer("revision").notNull().default(0),
  expiresAt: integer("expires_at").notNull(),
}, table => [index("fate_rooms_expiry").on(table.expiresAt)]);
export const rateLimits = sqliteTable("fate_limits", {
  key: text("key").primaryKey(),
  count: integer("count").notNull(),
  expiresAt: integer("expires_at").notNull(),
}, table => [index("fate_limits_expiry").on(table.expiresAt)]);
